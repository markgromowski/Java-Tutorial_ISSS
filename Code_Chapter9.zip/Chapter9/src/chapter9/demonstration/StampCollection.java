package chapter9.demonstration;

import java.util.ArrayList;
import java.util.List;

public class StampCollection {
	
	private List<Stamp> stamps = new ArrayList<Stamp>();

	public List<Stamp> getStamps() {
		return stamps;
	}

	public void setStamps(List<Stamp> stamps) {
		this.stamps = stamps;
	}
	
	public void showCollection() {
		for(Stamp s : stamps) {
			System.out.println(s.getName());
		}
	}

}
