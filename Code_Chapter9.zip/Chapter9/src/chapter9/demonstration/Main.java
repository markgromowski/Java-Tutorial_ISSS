package chapter9.demonstration;

public class Main {

	public static void main(String[] args) {
		
		int i = 5;
		int j = 0;
		
		//Use defensive programming to avoid an ArithmeticException
		if(j != 0) {
			int k = i / j;
			System.out.println(k);
		}
		
		String s = "Hello";
		
		//Use defensive programming to avoid a StringIndexOutOfBoundsException
		if(i < s.length()) {
			char c = s.charAt(i);	
			System.out.println(c);
		}
		
		int[] numbers = {5, 10, 15, 20, 25};
		
		//Use defensive programming to avoid an ArrayIndexOutOfBoundsException
		if(i < numbers.length) {
			int number = numbers[i];	
			System.out.println(number);
		}
		
		Hero hero = new SuperHero();
		
		//Use defensive programming to avoid a ClassCastException
		if(hero instanceof SuperHero) {
			SuperHero hero2 = (SuperHero) hero;	
			System.out.println("Casting sucessful");
		}
		
		StampCollector peter = new StampCollector("Peter", new StampCollection());
		
		//Use defensive programming to avoid a NullPointerException
		if(peter.getCollection().getStamps() != null) {
			peter.showCollection();
			System.out.println("Collection is not null");
		}
		
		//Don't use endless recursion to avoid a StackOverflowError
		//endlessRecursion();
		
	}
	
	public static void endlessRecursion() {
		endlessRecursion();
	}

}
