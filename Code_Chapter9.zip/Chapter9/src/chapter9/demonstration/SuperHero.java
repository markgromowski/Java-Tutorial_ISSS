package chapter9.demonstration;

public class SuperHero extends Hero {

}
