package chapter9.demonstration;

public class Hero {

}
