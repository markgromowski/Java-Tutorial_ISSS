package chapter9.scanner;

import java.util.Scanner;

public class ScannerTest {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter a number: ");
		String s = sc.next();
		
		try {
			int i = Integer.parseInt(s);	
			System.out.println("Your input was: " + i);
		} catch(NumberFormatException e) {
			System.err.println("Invalid input!");
		}

	}

}
