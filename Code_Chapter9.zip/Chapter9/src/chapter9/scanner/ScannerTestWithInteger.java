package chapter9.scanner;

import java.util.Scanner;

public class ScannerTestWithInteger {
	
	public static void main(String[] args) {
		
		String s = readIntegerAndParseToString();
		System.out.println(s);

	}
	
	public static String readIntegerAndParseToString() {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a number in the range from 1 to 3:");
		String choice = scanner.next();
		
		try {
			int number = Integer.parseInt(choice);
			if(number == 1) {
				return "You choose option 1";
			} else if(number == 2) {
				return "You choose option 2";
			} else if(number == 3) {
				return "You choose option 3";
			} else {
				System.err.println("Invalid number! Try again!");
				return readIntegerAndParseToString();
			}
		} catch (NumberFormatException e) {
			System.err.println("Invalid input! Try again!");
			return readIntegerAndParseToString();
		}
		
	}

}
