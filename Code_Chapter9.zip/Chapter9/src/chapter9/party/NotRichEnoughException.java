package chapter9.party;

public class NotRichEnoughException extends NotInvitedException {
	
	public NotRichEnoughException() {
		super("The person is not rich enough");
	}

}
