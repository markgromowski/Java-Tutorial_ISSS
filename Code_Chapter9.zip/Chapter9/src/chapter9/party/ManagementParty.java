package chapter9.party;

public class ManagementParty extends CompanyParty {
	
	public ManagementParty(Location location) {
		super(location);
	}

	@Override
	public void participate(Person person) throws NotInvitedException, NotRichEnoughException {
		if(person.getEmployment() != this.getLocation()) {
			throw new NotInvitedException();
		} else if(person.getSalary() < 500000) {
			throw new NotRichEnoughException();
		} else {
			getGuests().add(person);
			System.out.println("Welcome to the party " + person.getName());
		}
	}

}
