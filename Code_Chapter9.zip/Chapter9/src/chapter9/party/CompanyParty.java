package chapter9.party;

import java.util.ArrayList;
import java.util.List;

public class CompanyParty implements Party {
	
	private Location location;
	private List<Person> guests;
	
	public CompanyParty(Location location) {
		super();
		this.location = location;
		guests = new ArrayList<Person>();
	}

	public Location getLocation() {
		return location;
	}

	@Override
	public void setLocation(Location location) {
		this.location = location;
	}

	public List<Person> getGuests() {
		return guests;
	}

	public void setGuests(List<Person> guests) {
		this.guests = guests;
	}

	@Override
	public void participate(Person person) throws NotInvitedException, NotRichEnoughException {
		if(person.getEmployment() == this.location) {
			guests.add(person);
			System.out.println("Welcome to the party " + person.getName());
		} else {
			throw new NotInvitedException();
		}
	}
	
	@Override
	public void showGuestList() {
		System.out.println("The following guests are currently at the party:");
		System.out.println("--------------------");
		for(Person p : guests) {
			System.out.println(p.getName());
		}
	}

}
