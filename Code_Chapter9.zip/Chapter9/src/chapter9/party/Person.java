package chapter9.party;

public class Person {
	
	private String name;
	private Company employment;
	private int salary;
	
	public Person(String name, Company employment, int salary) {
		super();
		this.name = name;
		this.employment = employment;
		this.salary = salary;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Company getEmployment() {
		return employment;
	}

	public void setEmployment(Company employment) {
		this.employment = employment;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

}
