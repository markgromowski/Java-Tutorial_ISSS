package chapter9.party;

import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		
		Company mercedes = new Company("Mercedes");
		Company bmw = new Company("BMW");
		
		Person michael = new Person("Michael", mercedes, 70000);
		Person eric = new Person("Eric", bmw, 800000);
		Person sarah = new Person("Sarah", mercedes, 900000);
		
		List<Person> persons = new ArrayList<Person>();
		persons.add(michael);
		persons.add(eric);
		persons.add(sarah);
		
		try {
			startParty(persons, mercedes);
		} catch (NotInvitedPersonsException e) {
			System.out.println("The following guests were not able to enter the party:");
			for(String name : e.getNames()) {
				System.out.println(name);
			}
		}
		
	}
	
	public static void startParty(List<Person> persons, Location location) throws NotInvitedPersonsException {
		ManagementParty party = new ManagementParty(location);
		List<String> names = new ArrayList<String>();
		for(Person  p: persons) {
			try {
				party.participate(p);
			} catch(NotRichEnoughException e) {
				names.add(p.getName());
			} catch(NotInvitedException e) {
				names.add(p.getName());
			}
		}
		if(names.size() != 0) {
			throw new NotInvitedPersonsException(names);			
		}
	}

}
