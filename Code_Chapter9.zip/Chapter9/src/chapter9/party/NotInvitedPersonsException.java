package chapter9.party;

import java.util.ArrayList;
import java.util.List;

public class NotInvitedPersonsException extends Exception {
	
	private List<String> names;
	
	public NotInvitedPersonsException(List<String> names) {
		super("Some persons are not invited");
		this.names = names;
	}

	public List<String> getNames() {
		return names;
	}

	public void setNames(List<String> names) {
		this.names = names;
	}

}
