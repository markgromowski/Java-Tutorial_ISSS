package chapter9.demonstration;

public class Main {

	public static void main(String[] args) {
		
		// Examples of defensive programming:
		
		int i = 5;
		int j = 0;

		if(j != 0) {
			int k = i / j;
			System.out.println(k);			
		} else {
			System.out.println("Divisor was 0");
		}
		
		String s = "Hello";
		
		if(i < s.length()) {
			char c = s.charAt(i);	
			System.out.println(c);			
		} else {
			System.out.println("String is not long enough");
		}
		
		int[] numbers = {5, 10, 15, 20, 25};
		
		if(i < numbers.length) {
			int number = numbers[i];	
			System.out.println(number);			
		} else {
			System.out.println("Array is not long enough");
		}
		
		Hero hero = new Hero();
		
		if(hero instanceof SuperHero) {
			SuperHero hero2 = (SuperHero) hero;
			System.out.println("Casting successful");
		} else {
			System.out.println("Casting not successful");
		}
		
		StampCollector peter = new StampCollector("Peter", new StampCollection());
		
		if(peter.getCollection().getStamps() != null) {
			peter.showCollection();		
		} else {
			System.out.println("Null pointer");
		}
		
	}

}
