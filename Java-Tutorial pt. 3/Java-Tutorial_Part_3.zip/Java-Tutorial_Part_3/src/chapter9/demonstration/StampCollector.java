package chapter9.demonstration;

public class StampCollector {
	
	private String name;
	private StampCollection collection;
	
	public StampCollector(String name, StampCollection collection) {
		super();
		this.name = name;
		this.collection = collection;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public StampCollection getCollection() {
		return collection;
	}

	public void setCollection(StampCollection collection) {
		this.collection = collection;
	}
	
	public void showCollection() {
		collection.showCollection();
	}

}
