package chapter9.scanner;

import java.util.Scanner;

public class ScannerTestWithInteger {
	
	public static void main(String[] args) {
		
		int i = readStringAndParseToInteger();
		System.out.println("Your input was " + i);
		switch (i) {
		case 1: System.out.println("Monday");
		break;
		case 2: System.out.println("Tuesday");
		break;
		case 3: System.out.println("Wednesday");
		break;
		case 4: System.out.println("Thursday");
		break;
		case 5: System.out.println("Friday");
		break;
		}

	}
	
	public static int readStringAndParseToInteger() {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter a number between 1 and 5");
		String newString = sc.next();
		
		try {
			int i = Integer.parseInt(newString);
			if(i >= 1 && i <= 5) {
				return i;				
			} else {
				System.out.println("Only numbers between 1 and 5 are allowed");
				System.out.println("");
				return readStringAndParseToInteger();
			}
		} catch (NumberFormatException e) {
			System.out.println("That was not a number");
			System.out.println("");
			return readStringAndParseToInteger();
		}
		
	}

}
