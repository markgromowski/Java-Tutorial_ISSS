package chapter9.party;

public class NotRichEnoughException extends NotInvitedException {
	
	private String name;
	
	public NotRichEnoughException(String name) {
		super("The person is not rich enough");
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
