package chapter9.party;

public interface Party {
	
	public abstract void setLocation(Location location);
	public abstract void participate(Person person) throws NotInvitedException, NotRichEnoughException;
	public abstract void showGuestList();

}
