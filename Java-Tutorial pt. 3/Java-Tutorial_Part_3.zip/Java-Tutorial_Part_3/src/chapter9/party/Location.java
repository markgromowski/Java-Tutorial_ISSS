package chapter9.party;

public interface Location {

}
