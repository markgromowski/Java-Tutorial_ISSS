package chapter9.party;

import java.util.List;

public class NotInvitedPersonsException extends Exception {

	List<String> notInvitedPersons;

	public NotInvitedPersonsException(List<String> notInvitedPersons) {
		super("Some persons are not invited");
		this.notInvitedPersons = notInvitedPersons;
	}

	public List<String> getNotInvitedPersons() {
		return notInvitedPersons;
	}

	public void setNotInvitedPersons(List<String> notInvitedPersons) {
		this.notInvitedPersons = notInvitedPersons;
	}
	
}
