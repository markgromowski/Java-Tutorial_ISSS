package chapter9.party;

import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		
		Company mercedes = new Company("Mercedes");
		Company bmw = new Company("BMW");
		
		Party mercedesParty = new ManagementParty(mercedes, new ArrayList<Person>());
		
		Person john = new Person("John", mercedes, 120000);
		Person eric = new Person("Eric", bmw, 600000);
		Person sarah = new Person("Sarah", mercedes, 500000);
		Person catrine = new Person("Catrine", bmw, 450000);
		Person leon = new Person("Leon", mercedes, 720000);
		
		try {
			mercedesParty.participate(john);
		} catch (NotRichEnoughException e) {
			System.out.println(e.getName() + " is not rich enough");
		} catch (NotInvitedException e) {
			System.out.println(john.getName() + " is not inivited");
		}
		
		try {
			mercedesParty.participate(eric);
		} catch (NotRichEnoughException e) {
			System.out.println(e.getName() + " is not rich enough");
		} catch (NotInvitedException e) {
			System.out.println(eric.getName() + " is not inivited");
		}
		
		try {
			mercedesParty.participate(sarah);
		} catch (NotRichEnoughException e) {
			System.out.println(e.getName() + " is not rich enough");
		} catch (NotInvitedException e) {
			System.out.println(sarah.getName() + " is not inivited");
		} finally {
			System.out.println("");
			mercedesParty.showGuestList();
		}
		
		System.out.println("");
		
		List<Person> possibleGuests = new ArrayList<Person>();
		possibleGuests.add(john);
		possibleGuests.add(eric);
		possibleGuests.add(sarah);
		possibleGuests.add(catrine);
		possibleGuests.add(leon);
		
		try {
			startParty(possibleGuests, mercedes);
		} catch (NotInvitedPersonsException e) {
			System.out.println("");
			System.out.println("The following persons were not invited:");
			System.out.println("--------------------");
			for(String name : e.getNotInvitedPersons()) {
				System.out.println(name);
			}
			System.out.println("--------------------");
		}

	}
	
	public static void startParty(List<Person> guests, Location location) throws NotInvitedPersonsException {
		Party party = new ManagementParty(location, new ArrayList<Person>());
		List<String> notInvitedPersons = new ArrayList<String>();
		
		for(Person guest : guests) {
			try {
				party.participate(guest);
			} catch (NotInvitedException e) {
				notInvitedPersons.add(guest.getName());
			}
		}
		
		if(!notInvitedPersons.isEmpty()) {
			throw new NotInvitedPersonsException(notInvitedPersons);
		}
	}

}
