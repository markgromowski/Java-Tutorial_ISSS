package chapter9.party;

public class NotInvitedException extends Exception {
	
	public NotInvitedException() {
		super("The person is not invited");
	}
	
	public NotInvitedException(String s) {
		super(s);
	}

}
