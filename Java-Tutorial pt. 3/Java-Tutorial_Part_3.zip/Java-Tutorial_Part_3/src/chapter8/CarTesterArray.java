package chapter8;

public class CarTesterArray implements CarTester {

	private Car[] cars = new Car[5];
	private int counter = 0;
	
	@Override
	public void addNewCar(Car c) {
		if(counter == cars.length) {
			Car[] newCars = new Car[cars.length + 10];
			for(int i = 0; i < counter; i++) {
				for(Car eachCar : cars) {
					newCars[i] = eachCar;
				}
			}
			cars = newCars;
		}
		cars[counter] = c;
		counter++;
	}

	@Override
	public boolean checkCar(Car c) {
		for(Car eachCar : cars) {
			if(eachCar.equals(c)) {
				return true;
			}
		}
		return false;
		
		// Alternative:
		// 	boolean result = false;
		// 	for(Car eachCar : cars) {
		// 		result = eachCar.equals(c);
		// 		if(result == true) {
		// 			break;				
		//		}
		// 	}
		// 	return result;
	}

	@Override
	public void showCarCollection() {
		for(int i = 0; i < counter; i++) {
			System.out.println(cars[i]);
		}
		
		// Alternative:
		// 	for(Car eachCar : cars) {
		// 		if(eachCar != null) {
		// 			System.out.println(eachCar);				
		//  	}
		// 	}
	}
	
	

}
