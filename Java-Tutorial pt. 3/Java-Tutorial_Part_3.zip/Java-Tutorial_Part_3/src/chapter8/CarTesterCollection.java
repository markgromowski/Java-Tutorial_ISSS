package chapter8;

import java.util.Collection;

public class CarTesterCollection implements CarTester {

	Collection<Car> cars;
	
	public CarTesterCollection(Collection<Car> cars) {
		this.cars = cars;
	}
	
	@Override
	public void addNewCar(Car c) {
		cars.add(c);
	}

	@Override
	public boolean checkCar(Car c) {
		return cars.contains(c);
	}

	@Override
	public void showCarCollection() {
		for(Car eachCar : cars) {
			System.out.println(eachCar);
		}
	}
	
}
