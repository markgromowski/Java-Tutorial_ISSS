package chapter8;

public class Car {
	
	private String name;
	private int price;
	private Engine engine;
	
	public Car(String name, int price, Engine engine) {
		super();
		this.name = name;
		this.price = price;
		this.engine = engine;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public Engine getEngine() {
		return engine;
	}

	public void setEngine(Engine engine) {
		this.engine = engine;
	}
	
	// Override the equals-method to be able to identify objects with identical values as equal
	@Override
	public boolean equals(Object obj) {
		
		if(obj != null && obj instanceof Car) {
			Car c = (Car) obj;
			
			boolean nameEqual = c.getName().equals(this.getName());
			boolean priceEqual = c.getPrice() == this.getPrice();
			boolean engineEqual = c.getEngine().equals(this.getEngine());
			
			if(nameEqual && priceEqual && engineEqual) {
				return true;
			}
			
			// Alternative:
			// 	return c.getName().equals(this.getName()) && c.getPrice() == this.getPrice() && c.getEngine().equals(this.getEngine());
		}
		return false;
		
	}

	@Override
	public String toString() {
		return "Car [name=" + name + ", price=" + price + ", engine=" + engine
				+ "]";
	}

}
