package chapter8;

import java.util.ArrayList;

public class Main {
	
	public static void showCars(Car[] cars) {
		for(int i = 0; i < cars.length; i++) {
			System.out.println((i+1) + ". Car: " + cars[i]);
		}
	}

	public static void main(String[] args) {
		
		Car c1 = new Car("Mercedes SLK", 120000, Engine.GAS_ENGINE);
		Car c2 = new Car("Audi TT", 80000, Engine.GAS_ENGINE);
		Car c3 = new Car("Renault Megane", 40000, Engine.ELECTRIC_MOTOR);
		Car c4 = new Car("Bentley Continental GT", 90000, Engine.DIESEL_ENGINE);
		Car c5 = new Car("BMW 520i", 60000, Engine.ELECTRIC_MOTOR);
		
		Car c6 = new Car("Rolls Royce", 300000, Engine.GAS_ENGINE);
		Car c7 = new Car("Mercedes SLK", 120000, Engine.GAS_ENGINE);
		
		// Arrays can be created via the constructor ... :
		Car[] cars = new Car[5];
		cars[1] = c1;
		cars[2] = new Car("Rolls Royce", 300000, Engine.GAS_ENGINE);
		
		System.out.println(cars[1]);
		System.out.println(cars[2]);
		System.out.println(cars[3]);
		
		System.out.println("");
		System.out.println("--------------------");
		System.out.println("");
		
		// ... via the short form (inserting all elements at once) ... :
		int[] numbers = {26, 44, 19, 79};
		
		System.out.println(numbers[1]);
		System.out.println(numbers[0]);
		System.out.println(numbers[3]);
		
		System.out.println("");
		System.out.println("--------------------");
		System.out.println("");
		
		// ... or anonymously as parameter of a method:
		showCars(new Car[]{c2, c3, c4});
		
		System.out.println("");
		System.out.println("--------------------");
		System.out.println("");
		
		// Arrays can have more than one dimension:
		int[][] matrix = new int[3][4];
		matrix[1][3] = 45;
		
		CarTester tester = new CarTesterCollection(new ArrayList<Car>());
		
		tester.addNewCar(c1);
		tester.addNewCar(c2);
		tester.addNewCar(c3);
		tester.addNewCar(c4);
		tester.addNewCar(c5);
		
		tester.showCarCollection();
		
		System.out.println("");
		
		System.out.println(tester.checkCar(c5));
		
		System.out.println("");
		
		System.out.println(tester.checkCar(c6));
		
		System.out.println("");
		
		System.out.println(tester.checkCar(c7));
		
		System.out.println("");
		
		tester.addNewCar(c6);
		
		tester.showCarCollection();
	
	}

}
