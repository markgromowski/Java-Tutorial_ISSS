package chapter8;

public enum Engine {
	
	DIESEL_ENGINE, ELECTRIC_MOTOR, GAS_ENGINE

}
