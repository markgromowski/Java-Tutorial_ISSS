package chapter8;

public interface CarTester {
	
	public abstract void addNewCar(Car c);
	public abstract boolean checkCar(Car c);
	public abstract void showCarCollection();

}
