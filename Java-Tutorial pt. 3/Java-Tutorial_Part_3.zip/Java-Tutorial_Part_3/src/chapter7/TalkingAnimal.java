package chapter7;

// The rules of inheritance can be applied to interfaces too
public interface TalkingAnimal extends MagicalAnimal {
	
	public abstract void sayHello();

}
