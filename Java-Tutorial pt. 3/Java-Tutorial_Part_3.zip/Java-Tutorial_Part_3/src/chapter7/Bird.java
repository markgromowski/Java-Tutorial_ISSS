package chapter7;

public class Bird extends Animal {
	
	public double flyingSpeed;

	public Bird(String name, int age, double height, double flyingSpeed) {
		super(name, age, height);
		this.flyingSpeed = flyingSpeed;
	}

	public double getFlyingSpeed() {
		return flyingSpeed;
	}

	public void setFlyingSpeed(double flyingSpeed) {
		this.flyingSpeed = flyingSpeed;
	}
	
	public double flyDistance(double distance) {
		return distance/flyingSpeed;
	}
	
	// Classes that extend an abstract class have to implement all abstract methods from the superclass
	@Override
	public double travelDistance(double distance) {
		return this.flyDistance(distance);
	}
	
	@Override
	public String toString() {
		return "Bird [flyingSpeed=" + flyingSpeed + "]";
	}
	
}
