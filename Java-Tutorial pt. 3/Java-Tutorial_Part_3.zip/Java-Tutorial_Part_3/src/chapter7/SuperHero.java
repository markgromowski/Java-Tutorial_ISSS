package chapter7;

public class SuperHero {
	
	private String name;
	private int strength;
	private Organization orga;
	
	public SuperHero(String name, int strength, Organization orga) {
		super();
		this.name = name;
		this.strength = strength;
		this.orga = orga;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getStrength() {
		return strength;
	}

	public void setStrength(int strength) {
		this.strength = strength;
	}

	public Organization getOrga() {
		return orga;
	}

	public void setOrga(Organization orga) {
		this.orga = orga;
	}

	@Override
	public String toString() {
		return "SuperHero [name=" + name + ", strength=" + strength + "]";
	}

}
