package chapter7;

public class ConstantClassExample {
	
	// The constructor of a constant class should be private as only the constants but not the class itself are used
	private ConstantClassExample() {
		
	}
	
	public static final String MY_FAVOURITE_COLOUR = "blue";
	public static final int MY_FAVOURITE_NUMBER = 7;

}
