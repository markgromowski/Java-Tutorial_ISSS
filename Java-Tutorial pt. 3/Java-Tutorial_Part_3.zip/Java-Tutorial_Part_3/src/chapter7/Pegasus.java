package chapter7;

// Every class can only extend one other class but implement more than one interfaces
public class Pegasus extends Horse implements FlyingCreature, TalkingAnimal {

	private double flyingSpeed;
	private boolean flyingMode;
	
	public Pegasus(String name, int age, double height, double runningSpeed,
			double flyingSpeed) {
		super(name, age, height, runningSpeed);
		this.flyingSpeed = flyingSpeed;
		flyingMode = false;
	}

	public double getFlyingSpeed() {
		return flyingSpeed;
	}

	public void setFlyingSpeed(double flyingSpeed) {
		this.flyingSpeed = flyingSpeed;
	}

	public boolean isFlyingMode() {
		return flyingMode;
	}

	public void setFlyingMode(boolean flyingMode) {
		this.flyingMode = flyingMode;
	}

	@Override
	public double flyDistance(double distance) {
		return distance/flyingSpeed;
	}
	
	@Override
	public double travelDistance(double distance) {
		if(flyingMode == true) {
			return flyDistance(distance);
		} else {
			return runDistance(distance);
		}
	}

	@Override
	public void sayHello() {
		System.out.println("Hello my name is " + this.getName());
	}

	@Override
	public void magicPower() {
		// magic power...
	}
	
}
