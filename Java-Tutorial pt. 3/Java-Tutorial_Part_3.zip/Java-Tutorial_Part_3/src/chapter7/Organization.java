package chapter7;

public enum Organization {
	
	AVENGERS, SHIELD, JUSTICE_LEAGUE, NINJA_TURTLES

}
