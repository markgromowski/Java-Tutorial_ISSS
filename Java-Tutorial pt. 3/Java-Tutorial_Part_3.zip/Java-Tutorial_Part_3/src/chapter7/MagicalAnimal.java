package chapter7;

public interface MagicalAnimal {
	
	public abstract void magicPower();

}
