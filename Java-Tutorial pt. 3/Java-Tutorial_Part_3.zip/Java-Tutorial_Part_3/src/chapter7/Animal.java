package chapter7;

// Abstract classes cannot be instantiated
public abstract class Animal {
	
	private String name;
	private int age;
	private double height;
	
	public Animal(String name, int age, double height) {
		super();
		this.name = name;
		this.age = age;
		this.height = height;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}
	
	// Abstract methods do not specify a method body
	public abstract double travelDistance(double distance);

	@Override
	public String toString() {
		return "Animal [name=" + name + ", age=" + age + ", height=" + height
				+ "]";
	}

}
