package chapter7;

public class Horse extends Animal {
	
	double runningSpeed;
	
	public Horse(String name, int age, double height, double runningSpeed) {
		super(name, age, height);
		this.runningSpeed = runningSpeed;
	}

	public double getRunningSpeed() {
		return runningSpeed;
	}

	public void setRunningSpeed(double runningSpeed) {
		this.runningSpeed = runningSpeed;
	}

	public double runDistance(double distance) {
		return distance/runningSpeed;
	}
	
	// Classes that extend an abstract class have to implement all abstract methods from the superclass
	@Override
	public double travelDistance(double distance) {
		return this.runDistance(distance);
	}

	@Override
	public String toString() {
		return "Horse [runningSpeed=" + runningSpeed + "]";
	}

}
