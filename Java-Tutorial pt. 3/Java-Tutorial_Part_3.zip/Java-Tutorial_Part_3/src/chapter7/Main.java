package chapter7;

// Constants from constant classes can be made available via static import
import static chapter7.ConstantClassExample.MY_FAVOURITE_NUMBER;

public class Main {

	public static void main(String[] args) {
		
		// Abstract classes cannot be instantiated ... :
		// Animal dog = new Animal("Pluto", 6, 7.4); -> this would not work!
		
		// ... but they can still be used as reference type:
		Animal blacky = new Horse("Blacky", 10, 12.2, 40);
		// When calling an abstract method, the implementation of the non-abstract subclass is automatically used:
		System.out.println(blacky.travelDistance(20));
		
		Bird tweety = new Bird("Tweety", 4, 5.6, 16);
		System.out.println(tweety.flyDistance(20));
		
		System.out.println("");
		System.out.println("--------------------");
		System.out.println("");
		
		Pegasus chrysaor = new Pegasus("Chrysaor", 3000, 13.6, 40, 80);
		System.out.println(chrysaor.runDistance(20));
		System.out.println(chrysaor.flyDistance(20));
		System.out.println(chrysaor.travelDistance(20));
		chrysaor.setFlyingMode(true);
		System.out.println(chrysaor.travelDistance(20));
		chrysaor.sayHello();
		
		System.out.println("");
		System.out.println("--------------------");
		System.out.println("");
		
		FlyingSuperHero superman = new FlyingSuperHero("Clark Kent", 100, Organization.JUSTICE_LEAGUE, 100, false);
		System.out.println(superman.flyDistance(20));
		
		System.out.println("");
		System.out.println("--------------------");
		System.out.println("");
		
		// Use constants by referencing the constant class ... :
		System.out.println(ConstantClassExample.MY_FAVOURITE_COLOUR);
		// ... or directly after a static import:
		System.out.println(MY_FAVOURITE_NUMBER);
		
	}

}
