package chapter7;

public interface FlyingCreature {
	
	// All methods in an interface have to be public and abstract
	public abstract double flyDistance(double distance);

}
