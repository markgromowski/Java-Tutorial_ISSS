package chapter7;

public class FlyingSuperHero extends SuperHero implements FlyingCreature {
	
	double flyingSpeed;
	boolean hasTeleportationPower;
	
	public FlyingSuperHero(String name, int strength, Organization orga, double flyingSpeed,
			boolean hasTeleportationPower) {
		super(name, strength, orga);
		this.flyingSpeed = flyingSpeed;
		this.hasTeleportationPower = hasTeleportationPower;
	}

	public double getFlyingSpeed() {
		return flyingSpeed;
	}

	public void setFlyingSpeed(double flyingSpeed) {
		this.flyingSpeed = flyingSpeed;
	}

	public boolean isHasTeleportationPower() {
		return hasTeleportationPower;
	}

	public void setHasTeleportationPower(boolean hasTeleportationPower) {
		this.hasTeleportationPower = hasTeleportationPower;
	}

	@Override
	public double flyDistance(double distance) {
		if(hasTeleportationPower == false) {
			double time = distance/flyingSpeed;
			return time;
		} else {
			return 0.0;
		}
	}
	
}
