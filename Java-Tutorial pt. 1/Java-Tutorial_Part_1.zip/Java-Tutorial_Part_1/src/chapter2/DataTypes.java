package chapter2;

public class DataTypes {

	public static void main(String[] args) {
		
		// Representing numbers:
		
		byte byteExample = 64;
		System.out.println(byteExample);
		short shortExample = 640;
		System.out.println(shortExample);
		int intExample = 640_000_000; // -> Standard for integer numbers
		System.out.println(intExample);
		long longExample = 64_000_000_000_000_000L; // -> Don't forget to append the L
		System.out.println(longExample);
		float floatExample = 0.64F; // -> Don't forget to append the F
		System.out.println(floatExample);
		double doubleExample = 0.000_000_000_000_000_064; // -> Standard for float point numbers
		System.out.println(doubleExample);
		
		System.out.println("");
		System.out.println("--------------------------------------------------");
		System.out.println("");
		
		double i = 5;
		double j = 4;				
		
		// Applying relational operators:
		
		System.out.println(i < j);
		System.out.println(i > j);
		System.out.println(i == j);
		System.out.println(i != j);
		
		System.out.println("");
		System.out.println("--------------------------------------------------");
		System.out.println("");

		// Applying arithmetic operators:
		
		double result = i + j;
		System.out.println(result);
		
		result = i - j;
		System.out.println(result);
		
		result = i * j;
		System.out.println(result);
		
		result = i / j;
		System.out.println(result);
		
		result = i % j;
		System.out.println(result);
		
		// Short forms:
		
		i += j; // Equals: i = i + j;
		i -= j; // Equals: i = i - j;
		i *= j; // Equals: i = i * j;
		i /= j; // Equals: i = i / j;
		i %= j; // Equals: i = i % j;
		i++; // Equals: i = i + 1;
		i--; // Equals: i = i - 1;
		
		System.out.println("");
		System.out.println("--------------------------------------------------");
		System.out.println("");
		
		// Conversion of the data type:
		
		// Widening works without problems:
		byte byteToTransform = 64;
		int byteAfterTransformation = byteToTransform;
		System.out.println(byteAfterTransformation);
		
		// Narrowing only works via Casting -> Warning: might result in inconsistencies!
		int intToTransform = 15001;
		byte intAfterTransformation = (byte) intToTransform;
		System.out.println(intAfterTransformation);
		
		System.out.println("");
		System.out.println("--------------------------------------------------");
		System.out.println("");
		
		// Applying boolean operators:
		
		boolean trueBoolean = true;
		boolean falseBoolean = false;
		
		System.out.println(trueBoolean && falseBoolean);
		System.out.println(trueBoolean || falseBoolean);
		System.out.println(!trueBoolean);
		System.out.println(trueBoolean ^ falseBoolean);

	}

}
