package chapter3;

public class TestScoresGroupSolution {

	public static void main(String[] args) {
		
		int score = -345;
		
		if(score >= 0 && score <= 100) {
			if(score < 60) {
				System.out.println("The grade for achieving " + score + " points is F");
			} else if(score >= 60 && score < 70) {
				System.out.println("The grade for achieving " + score + " points is D");
			} else if(score >= 70 && score < 80) {
				System.out.println("The grade for achieving " + score + " points is C");
			} else if(score >= 80 && score < 90) {
				System.out.println("The grade for achieving " + score + " points is B");
			} else {
				System.out.println("The grade for achieving " + score + " points is A");
			}
		} else {
			System.out.println("The score can only be a number between 0 and 100");
		}
		
	}
	
}
