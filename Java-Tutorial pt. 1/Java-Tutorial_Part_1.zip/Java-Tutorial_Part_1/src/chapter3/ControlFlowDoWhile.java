package chapter3;

public class ControlFlowDoWhile {

	public static void main(String[] args) {
	
		int i = 10;
		
		while(i <= 5) {
			System.out.println(i);
			i++;
		}
		
		System.out.println("");
		System.out.println("--------------------------------------------------");
		System.out.println("");
		
		int j = 10;
		
		do {	
			System.out.println(j);
			j++;
		} while(j <= 5);
		
	}
	
}
