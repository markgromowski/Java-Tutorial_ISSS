package chapter3;

public class PrimeNumbersGroupSolution {

	public static void main(String[] args) {
		
		boolean isPrime = false;
		
		System.out.println(1);
		System.out.println(2);
		
		for(int i = 1; i <= 100; i++) {
			
			for(int j = 2; j < i; j++) {
				
				if(i % j == 0) {
					isPrime = false;
					break;
				} else {
					isPrime = true;
				}
	
			}
			
			if(isPrime == true) {
				System.out.println(i);
			}
			
		}
		
	}

}
