package chapter3;

public class ControlFlowIf {

	public static void main(String[] args) {
		
		int i = 10;
		
		if(i < 10) {
			System.out.println(i + " is smaller than 10!");
		} else if (i > 10) {
			System.out.println(i + " is greater than 10!");
		} else {
			System.out.println(i + " is exactly 10!");
		}
		
	}
	
}
