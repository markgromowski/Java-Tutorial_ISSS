package chapter3;

public class ControlFlowWhile {

	public static void main(String[] args) {
		
		int i = 0;
		
		while(i <= 5) {
			System.out.println(i);
			i++;	
		}

	}

}
