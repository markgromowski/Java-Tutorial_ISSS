package chapter6.heroes;

public class HeroTest {

	public static void main(String[] args) {
		
		Person jimmy = new Person("Jimmy", 24, 1.68);
		jimmy.sayHello();
		
		if(jimmy instanceof Hero) {
			Hero superJimmy = (Hero) jimmy;
			superJimmy.attack(12);			
		} else {
			System.out.println("casting not successful");
		}
		
		Hero spiderman = new Hero("Peter Parker", 19, 1.78, 40);
		spiderman.sayHello();
		System.out.println(spiderman.attack(12));
		
		Person bruceWayne = new Hero("Bruce Wayne", 41, 1.86, 50);
		bruceWayne.sayHello();
		
		if(bruceWayne instanceof Hero) {
			Hero batman = (Hero) bruceWayne;
			System.out.println(batman.attack(12));			
		} else {
			System.out.println("casting not successful");
		}

		SuperHero superman = new SuperHero("Clark Kent", 32, 1.82, 60);
		superman.sayHello();
		System.out.println(superman.attack(12));
		
		Hero updatedSuperman = superman;
		System.out.println(updatedSuperman.attack(12));
		
	}

}
