package chapter6.heroes;

public class SuperHero extends Hero {
	
	public SuperHero(String name, int age, double height, int strength) {
		super(name, age, height, strength);
	}

	@Override
	public int attack(int defense) {
		return getStrength()-defense/2;
	}

}
