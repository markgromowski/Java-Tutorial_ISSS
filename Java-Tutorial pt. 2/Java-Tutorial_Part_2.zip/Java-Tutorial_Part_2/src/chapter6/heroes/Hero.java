package chapter6.heroes;

public class Hero extends Person {
	
	private int strength;
	
	public Hero(String name, int age, double height, int strength) {
		super(name, age, height);
		this.strength = strength;
	}

	public int getStrength() {
		return strength;
	}

	public void setStrength(int strength) {
		this.strength = strength;
	}
	
	public int attack(int defense) {
		return strength-defense;
	}

}
