package chapter6.band;

public class Drummer {

	private String name;
	private int age;
	private double heigth;
	private Drums drums;
	
	public Drummer(String name, int age, double heigth, Drums drums) {
		super();
		this.name = name;
		this.age = age;
		this.heigth = heigth;
		this.drums = drums;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public double getHeigth() {
		return heigth;
	}

	public void setHeigth(double heigth) {
		this.heigth = heigth;
	}

	public Drums getDrums() {
		return drums;
	}

	public void setDrums(Drums drums) {
		this.drums = drums;
	}

	public void playMusic() {
		System.out.println("Drum sound");
	}
	
	@Override
	public String toString() {
		return "Drummer [name=" + name + ", age=" + age + ", heigth=" + heigth
				+ ", drums=" + drums + "]";
	}
	
}
