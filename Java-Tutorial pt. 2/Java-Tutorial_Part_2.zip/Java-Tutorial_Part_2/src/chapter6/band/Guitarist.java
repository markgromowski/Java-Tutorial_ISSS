package chapter6.band;

public class Guitarist {

	private String name;
	private int age;
	private double heigth;
	private Guitar guitar;
	
	public Guitarist(String name, int age, double heigth, Guitar guitar) {
		super();
		this.name = name;
		this.age = age;
		this.heigth = heigth;
		this.guitar = guitar;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public double getHeigth() {
		return heigth;
	}

	public void setHeigth(double heigth) {
		this.heigth = heigth;
	}

	public Guitar getGuitar() {
		return guitar;
	}

	public void setGuitar(Guitar guitar) {
		this.guitar = guitar;
	}

	public void playMusic() {
		System.out.println("Guitar sound");
	}
	
	@Override
	public String toString() {
		return "Guitarist [name=" + name + ", age=" + age + ", heigth="
				+ heigth + ", guitar=" + guitar + "]";
	}
	
}
