package chapter6.band;

public class Bass {

}
