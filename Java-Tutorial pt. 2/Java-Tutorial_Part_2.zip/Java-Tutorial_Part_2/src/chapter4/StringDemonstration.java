package chapter4;

import java.util.Arrays;

public class StringDemonstration {

	public static void main(String[] args) {
		
		String s = "Further Content";
		
		System.out.println(s.charAt(5));
		System.out.println(s.length());
		System.out.println(s.substring(8));
		System.out.println(s.substring(5, 10));
		System.out.println(Arrays.toString(s.split("e")));
		System.out.println(s.equals("Further Content"));
		System.out.println(s.startsWith("Fur"));
		System.out.println(s.endsWith("tent"));
		System.out.println(s.regionMatches(9, "Montecarlo", 1, 4));
		System.out.println(s.indexOf('t'));
		System.out.println(s.indexOf("Con"));
		System.out.println(s.indexOf('t', 5));
		System.out.println(s.contains("her"));
		System.out.println(s.replace("nt", "lol"));
		
	}

}
