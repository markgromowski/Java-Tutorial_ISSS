package chapter5;

public class Dog {
	
	private String name;
	private int age;
	private double height;
	private String breed;
	
	public Dog(String name, int age, double height) {
		this.name = name;
		this.age = age;
		this.height = height;
		this.breed = "Dalmatian";
	}
	
	public Dog(String name, int age, double height, String breed) {
		this.name = name;
		this.age = age;
		this.height = height;
		this.breed = breed;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		if(age >= 0) {
			this.age = age;			
		} else {
			System.out.println("Age cannot be negative!");
		}
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public String getBreed() {
		return breed;
	}

	public void setBreed(String breed) {
		this.breed = breed;
	}

	public void sayHello() {
		System.out.println("Hello my name is " + name);
	}
	
	public static void calculatePrime() {
		for(int i = 1; i <= 100; i++) {
			boolean isPrime = true;
			for(int j = 2; j < i; j++) {
				if(i % j == 0) {
					isPrime = false;
					break;
				}
			}
			if(isPrime == true) {
				System.out.println(i);
			}
		}
	}

	@Override
	public String toString() {
		return "Dog [name=" + name + ", age=" + age + ", height=" + height
				+ ", breed=" + breed + "]";
	}

}
