package chapter5;

public class HelloWorld {
	
	public static void main(String[] args) {
		
		String message = sayHello("World");
		System.out.println(message);
		
		Dog pluto = new Dog("Pluto", 7, 4.5);
		
		System.out.println(pluto.getName());
		System.out.println(pluto.getAge());
		System.out.println(pluto.getHeight());
		System.out.println(pluto);
		
		Person peter = new Person("Peter", 24, "Lassie", 6, 6.2);
		
		System.out.println(peter);
		
	}
	
	/**
	 * Says hello to a given entity.
	 * 
	 * @param name the name of the thing we say hello to.
	 * @return a message that says hello to the given thing.
	 */
	public static String sayHello(String name) {
		return "Hello " + name;
	}
	
}
